import * as i0 from "@angular/core";
import { Component, booleanAttribute, computed, input } from "@angular/core";
import { CodeWell } from "@brand-ui/atomic/atoms";
import { LoadingSkeleton, MediaArea } from "@brand-ui/atomic/molecules";
var Card = class Card {
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	description = input(...ngDevMode ? [void 0, { debugName: "description" }] : /* istanbul ignore next */ []);
	meta = input(...ngDevMode ? [void 0, { debugName: "meta" }] : /* istanbul ignore next */ []);
	tag = input(...ngDevMode ? [void 0, { debugName: "tag" }] : /* istanbul ignore next */ []);
	mediaLabel = input(...ngDevMode ? [void 0, { debugName: "mediaLabel" }] : /* istanbul ignore next */ []);
	href = input(...ngDevMode ? [void 0, { debugName: "href" }] : /* istanbul ignore next */ []);
	codeSample = input(...ngDevMode ? [void 0, { debugName: "codeSample" }] : /* istanbul ignore next */ []);
	loading = input(false, {
		...ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	interactive = computed(() => !this.loading() && !!this.href(), ...ngDevMode ? [{ debugName: "interactive" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Card,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: Card,
		isStandalone: true,
		selector: "bui-card",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			meta: {
				classPropertyName: "meta",
				publicName: "meta",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tag: {
				classPropertyName: "tag",
				publicName: "tag",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mediaLabel: {
				classPropertyName: "mediaLabel",
				publicName: "mediaLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			href: {
				classPropertyName: "href",
				publicName: "href",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			codeSample: {
				classPropertyName: "codeSample",
				publicName: "codeSample",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loading: {
				classPropertyName: "loading",
				publicName: "loading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: { "attr.title": "null" } },
		ngImport: i0,
		template: "<article\n  class=\"card\"\n  [attr.data-interactive]=\"interactive() ? '' : null\"\n  [attr.aria-busy]=\"loading() ? 'true' : null\"\n>\n  @if (loading()) {\n    <bui-loading-skeleton />\n    <span class=\"visually-hidden\">Loading</span>\n  } @else {\n    <bui-media-area [label]=\"mediaLabel()\" [tag]=\"tag()\" />\n    <div class=\"body\">\n      <h3 class=\"title\">\n        @if (interactive()) {\n          <a class=\"link\" [href]=\"href()\">{{ title() }}</a>\n        } @else {\n          {{ title() }}\n        }\n      </h3>\n      @if (description(); as description) {\n        <p class=\"text\">{{ description }}</p>\n      }\n      @if (codeSample(); as codeSample) {\n        <bui-code-well>{{ codeSample }}</bui-code-well>\n      }\n      @if (meta(); as meta) {\n        <p class=\"meta\">{{ meta }}</p>\n      }\n    </div>\n  }\n</article>\n",
		styles: [":host{display:block;min-width:0}.card{--_border: var(--bui-color-border);--_shadow: var(--bui-elevation-card);--_outline: none;--_link-decoration: none;--_stretch-0: \"\";position:relative;box-sizing:border-box;display:flex;flex-direction:column;min-width:0;overflow:hidden;background:var(--bui-color-surface);color:var(--bui-color-text);border:var(--bui-border-width) solid var(--bui-state-border, var(--_border));border-radius:var(--bui-radius-card);border-top-right-radius:var(--bui-radius-tr-card);corner-top-right-shape:var(--bui-corner-shape-card);box-shadow:var(--bui-state-shadow, var(--_shadow));outline:var(--bui-state-outline, var(--_outline));outline-offset:var(--bui-focus-offset);font-family:var(--bui-font-body);font-size:var(--bui-size-body)}.card[data-interactive]{cursor:pointer}.card[data-interactive]:hover{--_border: var(--bui-color-border-strong);--_shadow: var(--bui-elevation-raised);--_link-decoration: underline}.card[data-interactive]:active{--_border: var(--bui-color-primary);--_shadow: var(--bui-elevation-card)}.card:focus-within{--_outline: var(--bui-focus-width) solid var(--bui-color-focus)}.body{display:flex;flex-direction:column;gap:var(--bui-space-2);padding:var(--bui-space-4)}.title{margin:0;font-family:var(--bui-font-display);font-weight:var(--bui-weight-display);font-size:var(--bui-size-title);line-height:var(--bui-line-height-title)}.text,.meta{margin:0}.meta{color:var(--bui-color-text-muted);font-size:var(--bui-size-small)}.link{color:inherit;text-decoration:var(--bui-state-link-decoration, var(--_link-decoration));text-decoration-thickness:var(--bui-indicator-width)}.link:focus-visible{outline:none}.link:after{content:var(--_stretch-0);position:absolute;inset:0}.visually-hidden{position:absolute;width:1px;height:1px;margin:-1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}\n"],
		dependencies: [
			{
				kind: "component",
				type: CodeWell,
				selector: "bui-code-well"
			},
			{
				kind: "component",
				type: LoadingSkeleton,
				selector: "bui-loading-skeleton"
			},
			{
				kind: "component",
				type: MediaArea,
				selector: "bui-media-area",
				inputs: ["label", "tag"]
			}
		]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Card,
	decorators: [{
		type: Component,
		args: [{
			selector: "bui-card",
			imports: [
				CodeWell,
				LoadingSkeleton,
				MediaArea
			],
			host: { "[attr.title]": "null" },
			template: "<article\n  class=\"card\"\n  [attr.data-interactive]=\"interactive() ? '' : null\"\n  [attr.aria-busy]=\"loading() ? 'true' : null\"\n>\n  @if (loading()) {\n    <bui-loading-skeleton />\n    <span class=\"visually-hidden\">Loading</span>\n  } @else {\n    <bui-media-area [label]=\"mediaLabel()\" [tag]=\"tag()\" />\n    <div class=\"body\">\n      <h3 class=\"title\">\n        @if (interactive()) {\n          <a class=\"link\" [href]=\"href()\">{{ title() }}</a>\n        } @else {\n          {{ title() }}\n        }\n      </h3>\n      @if (description(); as description) {\n        <p class=\"text\">{{ description }}</p>\n      }\n      @if (codeSample(); as codeSample) {\n        <bui-code-well>{{ codeSample }}</bui-code-well>\n      }\n      @if (meta(); as meta) {\n        <p class=\"meta\">{{ meta }}</p>\n      }\n    </div>\n  }\n</article>\n",
			styles: [":host{display:block;min-width:0}.card{--_border: var(--bui-color-border);--_shadow: var(--bui-elevation-card);--_outline: none;--_link-decoration: none;--_stretch-0: \"\";position:relative;box-sizing:border-box;display:flex;flex-direction:column;min-width:0;overflow:hidden;background:var(--bui-color-surface);color:var(--bui-color-text);border:var(--bui-border-width) solid var(--bui-state-border, var(--_border));border-radius:var(--bui-radius-card);border-top-right-radius:var(--bui-radius-tr-card);corner-top-right-shape:var(--bui-corner-shape-card);box-shadow:var(--bui-state-shadow, var(--_shadow));outline:var(--bui-state-outline, var(--_outline));outline-offset:var(--bui-focus-offset);font-family:var(--bui-font-body);font-size:var(--bui-size-body)}.card[data-interactive]{cursor:pointer}.card[data-interactive]:hover{--_border: var(--bui-color-border-strong);--_shadow: var(--bui-elevation-raised);--_link-decoration: underline}.card[data-interactive]:active{--_border: var(--bui-color-primary);--_shadow: var(--bui-elevation-card)}.card:focus-within{--_outline: var(--bui-focus-width) solid var(--bui-color-focus)}.body{display:flex;flex-direction:column;gap:var(--bui-space-2);padding:var(--bui-space-4)}.title{margin:0;font-family:var(--bui-font-display);font-weight:var(--bui-weight-display);font-size:var(--bui-size-title);line-height:var(--bui-line-height-title)}.text,.meta{margin:0}.meta{color:var(--bui-color-text-muted);font-size:var(--bui-size-small)}.link{color:inherit;text-decoration:var(--bui-state-link-decoration, var(--_link-decoration));text-decoration-thickness:var(--bui-indicator-width)}.link:focus-visible{outline:none}.link:after{content:var(--_stretch-0);position:absolute;inset:0}.visually-hidden{position:absolute;width:1px;height:1px;margin:-1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}\n"]
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}],
		meta: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "meta",
				required: false
			}]
		}],
		tag: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tag",
				required: false
			}]
		}],
		mediaLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mediaLabel",
				required: false
			}]
		}],
		href: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "href",
				required: false
			}]
		}],
		codeSample: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "codeSample",
				required: false
			}]
		}],
		loading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}]
	}
});
export { Card };
