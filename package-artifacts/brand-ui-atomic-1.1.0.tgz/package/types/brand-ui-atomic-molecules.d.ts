import * as i0 from "@angular/core";
/**
 * Decorative placeholder arrangement for a loading card. It carries no busy state and no text:
 * the owning organism announces loading.
 */
export declare class LoadingSkeleton {
  static ɵfac: i0.ɵɵFactoryDeclaration<LoadingSkeleton, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<LoadingSkeleton, "bui-loading-skeleton", never, {}, {}, never, never, true, never>;
}
/** The 4:3 media surface: an optional placeholder label and an optional accent tag. */
export declare class MediaArea {
  readonly label: import("@angular/core").InputSignal<string | undefined>;
  readonly tag: import("@angular/core").InputSignal<string | undefined>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MediaArea, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MediaArea, "bui-media-area", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "tag": {
      "alias": "tag";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}