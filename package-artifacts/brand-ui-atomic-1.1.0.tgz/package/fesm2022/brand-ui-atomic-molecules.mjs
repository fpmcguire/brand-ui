import * as i0 from "@angular/core";
import { Component, input } from "@angular/core";
import { SkeletonBlock, Tag } from "@brand-ui/atomic/atoms";
var LoadingSkeleton = class LoadingSkeleton {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: LoadingSkeleton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: LoadingSkeleton,
		isStandalone: true,
		selector: "bui-loading-skeleton",
		host: { attributes: { "aria-hidden": "true" } },
		ngImport: i0,
		template: `
    <bui-skeleton-block class="media skeleton" />
    <div class="body">
      <bui-skeleton-block class="skeleton skeleton-title" />
      <bui-skeleton-block class="skeleton skeleton-line" />
      <bui-skeleton-block class="skeleton skeleton-line skeleton-short" />
    </div>
  `,
		isInline: true,
		styles: [":host{display:block}.media{box-sizing:border-box;aspect-ratio:4/3;flex-direction:column;align-items:flex-start;justify-content:space-between;padding:var(--bui-space-3);color:var(--bui-color-text-muted);font-size:var(--bui-size-small)}.body{display:flex;flex-direction:column;gap:var(--bui-space-2);padding:var(--bui-space-4)}.skeleton-title,.skeleton-line{border-radius:var(--bui-radius-control)}.skeleton-title{width:60%;height:var(--bui-space-5)}.skeleton-line{width:100%;height:var(--bui-space-3)}.skeleton-short{width:40%}\n"],
		dependencies: [{
			kind: "component",
			type: SkeletonBlock,
			selector: "bui-skeleton-block"
		}]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LoadingSkeleton,
	decorators: [{
		type: Component,
		args: [{
			selector: "bui-loading-skeleton",
			imports: [SkeletonBlock],
			template: `
    <bui-skeleton-block class="media skeleton" />
    <div class="body">
      <bui-skeleton-block class="skeleton skeleton-title" />
      <bui-skeleton-block class="skeleton skeleton-line" />
      <bui-skeleton-block class="skeleton skeleton-line skeleton-short" />
    </div>
  `,
			host: { "aria-hidden": "true" },
			styles: [":host{display:block}.media{box-sizing:border-box;aspect-ratio:4/3;flex-direction:column;align-items:flex-start;justify-content:space-between;padding:var(--bui-space-3);color:var(--bui-color-text-muted);font-size:var(--bui-size-small)}.body{display:flex;flex-direction:column;gap:var(--bui-space-2);padding:var(--bui-space-4)}.skeleton-title,.skeleton-line{border-radius:var(--bui-radius-control)}.skeleton-title{width:60%;height:var(--bui-space-5)}.skeleton-line{width:100%;height:var(--bui-space-3)}.skeleton-short{width:40%}\n"]
		}]
	}]
});
var MediaArea = class MediaArea {
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	tag = input(...ngDevMode ? [void 0, { debugName: "tag" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MediaArea,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: MediaArea,
		isStandalone: true,
		selector: "bui-media-area",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tag: {
				classPropertyName: "tag",
				publicName: "tag",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    @if (label(); as label) {
      <span class="media-label">{{ label }}</span>
    }
    @if (tag(); as tag) {
      <bui-tag>{{ tag }}</bui-tag>
    }
  `,
		isInline: true,
		styles: [":host{box-sizing:border-box;aspect-ratio:4/3;display:flex;flex-direction:column;align-items:flex-start;justify-content:space-between;padding:var(--bui-space-3);background:var(--bui-color-surface-sunken);color:var(--bui-color-text-muted);font-size:var(--bui-size-small)}\n"],
		dependencies: [{
			kind: "component",
			type: Tag,
			selector: "bui-tag"
		}]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MediaArea,
	decorators: [{
		type: Component,
		args: [{
			selector: "bui-media-area",
			imports: [Tag],
			template: `
    @if (label(); as label) {
      <span class="media-label">{{ label }}</span>
    }
    @if (tag(); as tag) {
      <bui-tag>{{ tag }}</bui-tag>
    }
  `,
			styles: [":host{box-sizing:border-box;aspect-ratio:4/3;display:flex;flex-direction:column;align-items:flex-start;justify-content:space-between;padding:var(--bui-space-3);background:var(--bui-color-surface-sunken);color:var(--bui-color-text-muted);font-size:var(--bui-size-small)}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		tag: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tag",
				required: false
			}]
		}]
	}
});
export { LoadingSkeleton, MediaArea };
