import * as i0 from "@angular/core";
/** Generic code well. The projected text is shown exactly as supplied. */
export declare class CodeWell {
  static ɵfac: i0.ɵɵFactoryDeclaration<CodeWell, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CodeWell, "bui-code-well", never, {}, {}, never, ["*"], true, never>;
}
/** Decorative pulsing placeholder. Size and shape belong to the arrangement that places it. */
export declare class SkeletonBlock {
  static ɵfac: i0.ɵɵFactoryDeclaration<SkeletonBlock, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SkeletonBlock, "bui-skeleton-block", never, {}, {}, never, never, true, never>;
}
/** Small accent label. Content is projected; the tag has no inputs and no semantics of its own. */
export declare class Tag {
  static ɵfac: i0.ɵɵFactoryDeclaration<Tag, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Tag, "bui-tag", never, {}, {}, never, ["*"], true, never>;
}