import * as i0 from "@angular/core";
import { Component } from "@angular/core";
var CodeWell = class CodeWell {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CodeWell,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: CodeWell,
		isStandalone: true,
		selector: "bui-code-well",
		ngImport: i0,
		template: "<pre class=\"code\"><code><ng-content /></code></pre>",
		isInline: true,
		styles: [":host{display:block}.code{box-sizing:border-box;margin:0;padding:var(--bui-space-3);background:var(--bui-color-bg);color:var(--bui-color-text);border:var(--bui-border-width) solid var(--bui-color-border);border-radius:var(--bui-radius-control);font-family:var(--bui-font-mono);font-size:var(--bui-size-small);line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CodeWell,
	decorators: [{
		type: Component,
		args: [{
			selector: "bui-code-well",
			template: "<pre class=\"code\"><code><ng-content /></code></pre>",
			styles: [":host{display:block}.code{box-sizing:border-box;margin:0;padding:var(--bui-space-3);background:var(--bui-color-bg);color:var(--bui-color-text);border:var(--bui-border-width) solid var(--bui-color-border);border-radius:var(--bui-radius-control);font-family:var(--bui-font-mono);font-size:var(--bui-size-small);line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere}\n"]
		}]
	}]
});
var SkeletonBlock = class SkeletonBlock {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SkeletonBlock,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: SkeletonBlock,
		isStandalone: true,
		selector: "bui-skeleton-block",
		host: { attributes: { "aria-hidden": "true" } },
		ngImport: i0,
		template: "",
		isInline: true,
		styles: [":host{display:block;background:var(--bui-color-surface-sunken);animation:pulse 1.4s ease-in-out infinite}@keyframes pulse{0%,to{opacity:1}50%{opacity:.45}}@media(prefers-reduced-motion:reduce){:host{animation:none}}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SkeletonBlock,
	decorators: [{
		type: Component,
		args: [{
			selector: "bui-skeleton-block",
			template: "",
			host: { "aria-hidden": "true" },
			styles: [":host{display:block;background:var(--bui-color-surface-sunken);animation:pulse 1.4s ease-in-out infinite}@keyframes pulse{0%,to{opacity:1}50%{opacity:.45}}@media(prefers-reduced-motion:reduce){:host{animation:none}}\n"]
		}]
	}]
});
var Tag = class Tag {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Tag,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: Tag,
		isStandalone: true,
		selector: "bui-tag",
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		styles: [":host{display:inline-block;padding:var(--bui-space-1) var(--bui-space-2);background:var(--bui-color-accent);color:var(--bui-color-on-accent);border-radius:var(--bui-radius-control);font-family:var(--bui-font-ui);font-weight:var(--bui-weight-ui)}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Tag,
	decorators: [{
		type: Component,
		args: [{
			selector: "bui-tag",
			template: "<ng-content />",
			styles: [":host{display:inline-block;padding:var(--bui-space-1) var(--bui-space-2);background:var(--bui-color-accent);color:var(--bui-color-on-accent);border-radius:var(--bui-radius-control);font-family:var(--bui-font-ui);font-weight:var(--bui-weight-ui)}\n"]
		}]
	}]
});
export { CodeWell, SkeletonBlock, Tag };
