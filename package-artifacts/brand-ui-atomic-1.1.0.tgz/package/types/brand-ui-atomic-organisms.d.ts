import * as i0 from "@angular/core";
export declare class Card {
  readonly title: import("@angular/core").InputSignal<string>;
  readonly description: import("@angular/core").InputSignal<string | undefined>;
  readonly meta: import("@angular/core").InputSignal<string | undefined>;
  readonly tag: import("@angular/core").InputSignal<string | undefined>;
  readonly mediaLabel: import("@angular/core").InputSignal<string | undefined>;
  /** With an `href` the title becomes the card's single native link; without one the card is static. */
  readonly href: import("@angular/core").InputSignal<string | undefined>;
  /** Optional generic code well. Supplied by the consumer; never inferred from the active brand. */
  readonly codeSample: import("@angular/core").InputSignal<string | undefined>;
  readonly loading: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly interactive: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Card, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Card, "bui-card", never, {
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
    "meta": {
      "alias": "meta";
      "required": false;
      "isSignal": true;
    };
    "tag": {
      "alias": "tag";
      "required": false;
      "isSignal": true;
    };
    "mediaLabel": {
      "alias": "mediaLabel";
      "required": false;
      "isSignal": true;
    };
    "href": {
      "alias": "href";
      "required": false;
      "isSignal": true;
    };
    "codeSample": {
      "alias": "codeSample";
      "required": false;
      "isSignal": true;
    };
    "loading": {
      "alias": "loading";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}